import{o as e,i as o}from"./.pnpm.7672c64c.js";import{d as r}from"./index.9b6794eb.js";const c={};function n(t,s){return e(),o("div",null," 重定向页面 ")}const f=r(c,[["render",n]]);export{f as default};
