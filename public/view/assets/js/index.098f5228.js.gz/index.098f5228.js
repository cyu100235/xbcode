import{o as e,g as o}from"./.pnpm.d6c3a9b7.js";import{d as r}from"./index.b8b6b2e9.js";const c={};function n(t,s){return e(),o("div",null," 重定向页面 ")}const f=r(c,[["render",n]]);export{f as default};
