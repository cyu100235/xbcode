import{o as e,g as o}from"./.pnpm.d6c3a9b7.js";import{d as r}from"./index.4e15015f.js";const c={};function n(t,s){return e(),o("div",null," 重定向页面 ")}const f=r(c,[["render",n]]);export{f as default};
