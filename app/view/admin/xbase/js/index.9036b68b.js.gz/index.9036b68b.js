import{o as e,i as o}from"./.pnpm.3ba29688.js";import{d as r}from"./index.ccfee414.js";const c={};function n(t,s){return e(),o("div",null," 重定向页面 ")}const f=r(c,[["render",n]]);export{f as default};
